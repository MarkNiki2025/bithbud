const date = document.getElementById('date');
const time = document.getElementById('time');
const btn = document.getElementById('btn');
const temperature = document.getElementById('temperature');
const rainfall = document.getElementById('rainfall');
const humidity = document.getElementById('relativeHumidity');
const windSpeed = document.getElementById('windSpeed');
const urls = {
    urlForTemperature: "https://api-open.data.gov.sg/v2/real-time/api/air-temperature",
    urlForRainfall: "https://api-open.data.gov.sg/v2/real-time/api/rainfall",
    urlForRelativeHumidity: 'https://api-open.data.gov.sg/v2/real-time/api/relative-humidity',
    urlForWindSpeed: 'https://api-open.data.gov.sg/v2/real-time/api/wind-speed',
};


async function load(src) {
    const response = await fetch(src);
    const data = await response.json()
    return data
}

function calculateAverage(arr) {
    let sum = 0;
    let count = 0;
    arr.forEach(e => {    
        e.data.forEach(item => {
            count++;
            sum += item.value
            })
    });
    return  Math.round((sum / count) * 10) / 10;
}

async function updateData (url,element, unit){
    const dataAll = await load(url);

    if (!dataAll.data) {
        element.textContent = dataAll.errorMsg;
        return;
    }

    const average = calculateAverage(dataAll.data.readings);
    element.textContent = `${average} ${unit}`
}


window.addEventListener("DOMContentLoaded", () => {
    updateData(urls.urlForTemperature,temperature, "°C");
    updateData(urls.urlForRainfall, rainfall, 'мм');
    updateData(urls.urlForRelativeHumidity, humidity, "%");
    updateData(urls.urlForWindSpeed, windSpeed, 'км/год');
})

btn.addEventListener('click', async () =>{
    const urlsMap = new Map();
    if (date.value) {
        if(time.value){
            for (let [key, url] of Object.entries(urls)) {
                    urlsMap.set(key, `${url}?date=${date.value}T${time.value}:00`);
                }
        }else {
            for (let [key, url] of Object.entries(urls)) {
                     urlsMap.set(key, `${url}?date=${date.value}`);
                }
        }
    }
    
    updateData(urlsMap.get("urlForTemperature"),temperature, "°C");
    updateData(urlsMap.get("urlForRainfall"),rainfall, 'мм');
    updateData(urlsMap.get("urlForRelativeHumidity"),humidity, "%"); 
    updateData(urlsMap.get("urlForWindSpeed"), windSpeed, 'км/год');
})

